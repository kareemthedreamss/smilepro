import { Link } from "react-router-dom";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Star } from "lucide-react";

// Sample products data
const products = [
  {
    id: 2,
    name: "Sonic Electric Toothbrush",
    slug: "sonic-electric-toothbrush",
    price: 89.99,
    rating: 4.8,
    reviewCount: 97,
    image: "/images/toothbrush.jpg",
    isNew: false,
    isBestSeller: true,
    category: "Electric Toothbrushes"
  },
  {
    id: 3,
    name: "Enamel Strengthening Mouthwash",
    slug: "enamel-strengthening-mouthwash",
    price: 19.99,
    rating: 4.6,
    reviewCount: 65,
    image: "/images/Mouthwash.jpg",
    isNew: true,
    isBestSeller: false,
    category: "Mouthwash"
  },
  {
    id: 4,
    name: "Sensitive Teeth Toothpaste",
    slug: "sensitive-teeth-toothpaste",
    price: 14.99,
    rating: 4.7,
    reviewCount: 82,
    image: "/images/Toothpaste.jpg",
    isNew: false,
    isBestSeller: false,
    category: "Toothpaste"
  },
  {
    id: 5,
    name: "Bamboo Floss Picks",
    slug: "bamboo-floss-picks",
    price: 8.99,
    rating: 4.5,
    reviewCount: 48,
    image: "/images/BambooFlossPicks.jpg",
    isNew: false,
    isBestSeller: false,
    category: "Floss"
  }
];

interface RelatedProductsProps {
  currentProductId: number;
}

export default function RelatedProducts({ currentProductId }: RelatedProductsProps) {
  // Filter out the current product from the related products
  const relatedProducts = products.filter(product => product.id !== currentProductId);
  
  return (
    <Carousel
      opts={{
        align: "start",
        loop: true,
      }}
      className="w-full"
    >
      <CarouselContent>
        {relatedProducts.map((product) => (
          <CarouselItem key={product.id} className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4 pl-4">
            <Link to={`/product/${product.slug}`}>
              <Card className="h-full hover:shadow-md transition-shadow overflow-hidden">
                <div className="relative aspect-square overflow-hidden">
                  {(product.isNew || product.isBestSeller) && (
                    <div className="absolute top-2 left-2 z-10">
                      {product.isNew && (
                        <Badge className="mb-2">New</Badge>
                      )}
                      {product.isBestSeller && (
                        <Badge variant="secondary" className="mb-2 ml-2">Best Seller</Badge>
                      )}
                    </div>
                  )}
                  <img
                    src={product.image}
                    alt={product.name}
                    className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium line-clamp-1">{product.name}</h3>
                  <div className="flex items-center gap-1 mt-1">
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${
                              i < Math.floor(product.rating)
                                ? "text-yellow-400 fill-yellow-400"
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                    </div>
                    <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-bold">${product.price.toFixed(2)}</span>
                    <Button variant="outline" size="sm">
                      View
                    </Button>
                  </div>
                </div>
              </Card>
            </Link>
          </CarouselItem>
        ))}
      </CarouselContent>
      <div className="flex justify-end gap-2 mt-4">
        <CarouselPrevious className="static translate-y-0" />
        <CarouselNext className="static translate-y-0" />
      </div>
    </Carousel>
  );
}