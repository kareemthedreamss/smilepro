import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

// Sample before/after data
const beforeAfterImages = [
  {
    id: 1,
    beforeImage: "/images/TeethWhitening.jpg",
    afterImage: "https://images.unsplash.com/photo-1601802221761-9c6eb7cc31f5?q=80&w=500&auto=format&fit=crop",
    category: "Teeth Whitening",
    customer: "Michelle, 34",
    description: "After just 2 weeks using our Professional Whitening Kit",
  },
  {
    id: 2,
    beforeImage: "https://images.unsplash.com/photo-1640185376875-6132fa3887f3?q=80&w=500&auto=format&fit=crop",
    afterImage: "https://images.unsplash.com/photo-1616428362406-3ffd541461e3?q=80&w=500&auto=format&fit=crop",
    category: "Electric Toothbrush",
    customer: "James, 42",
    description: "After 1 month of using our Sonic Electric Toothbrush",
  },
  {
    id: 3,
    beforeImage: "/images/TeethWhitening.jpg",
    afterImage: "https://images.unsplash.com/photo-1608229191360-7064b0afa639?q=80&w=500&auto=format&fit=crop",
    category: "Complete Routine",
    customer: "Lisa, 28",
    description: "After 3 weeks of using our Complete Oral Care Set",
  },
];

export default function BeforeAfterGallery() {
  const [activeTab, setActiveTab] = useState("all");
  
  const filteredImages = 
    activeTab === "all" 
      ? beforeAfterImages 
      : beforeAfterImages.filter(image => image.category.toLowerCase() === activeTab.toLowerCase());

  return (
    <section className="py-16 bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="mb-2">Real Results</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            See the difference our products make with these real customer before and after photos.
          </p>
        </div>

        <Tabs defaultValue="all" className="w-full" value={activeTab} onValueChange={setActiveTab}>
          <div className="flex justify-center mb-8">
            <TabsList className="grid grid-cols-3 sm:grid-cols-4 max-w-md">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="teeth whitening">Whitening</TabsTrigger>
              <TabsTrigger value="electric toothbrush">Toothbrush</TabsTrigger>
              <TabsTrigger value="complete routine">Complete</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value={activeTab} className="mt-0">
            <div className="gallery-container">
              {filteredImages.map((item) => (
                <div key={item.id} className="space-y-8">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="before-after-image">
                      <Badge className="absolute top-2 left-2 bg-gray-800/80 text-white z-10">Before</Badge>
                      <img 
                        src={item.beforeImage} 
                        alt={`${item.customer} Before`} 
                        className="w-full h-full object-cover aspect-square"
                      />
                    </div>
                    <div className="before-after-image">
                      <Badge className="absolute top-2 left-2 bg-primary/90 text-white z-10">After</Badge>
                      <img 
                        src={item.afterImage} 
                        alt={`${item.customer} After`} 
                        className="w-full h-full object-cover aspect-square"
                      />
                    </div>
                  </div>
                  <div className="text-center">
                    <h4 className="text-base font-medium">{item.customer}</h4>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                    <Badge variant="outline" className="mt-2">{item.category}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}