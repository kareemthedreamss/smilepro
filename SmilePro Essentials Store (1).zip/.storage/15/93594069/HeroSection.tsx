import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="hero-section">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <h1 className="font-bold">Your Brighter Smile Starts Here</h1>
            <p className="text-lg text-muted-foreground">
              Professional-grade dental products for a whiter, healthier smile. Dentist-approved solutions that are gentle on your enamel.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" className="font-medium">
                <Link to="/shop">Shop All Products</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/about">Learn More</Link>
              </Button>
            </div>
            <div className="flex items-center gap-4 pt-4">
              <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-10 w-10 rounded-full border-2 border-white bg-gray-200" />
                ))}
              </div>
              <p className="text-sm font-medium">
                Trusted by <span className="text-primary">10,000+</span> happy customers
              </p>
            </div>
          </div>
          <div className="lg:order-last order-first">
            <div className="relative">
              <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1606265752439-1f18756aa8ed?q=80&w=1000&auto=format&fit=crop"
                  alt="Smiling woman with white teeth"
                  className="object-cover w-full h-full"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white rounded-lg shadow-lg p-4 max-w-[200px]">
                <div className="flex items-center gap-2 mb-2">
                  <div className="bg-primary/10 rounded-full p-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M12 2H2v10l9.29 9.29c.94.94 2.48.94 3.42 0l6.58-6.58c.94-.94.94-2.48 0-3.42L12 2Z" />
                      <path d="M7 7h.01" />
                    </svg>
                  </div>
                  <span className="font-medium text-sm">Dentist Approved</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  All our products are tested and approved by professional dentists.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}