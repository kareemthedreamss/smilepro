import { Shield, Star, BadgeCheck, RefreshCcw } from "lucide-react";

const features = [
  {
    icon: <Shield className="feature-icon" />,
    title: "Dentist Approved",
    description: "All products are tested and approved by professional dentists for safety and efficacy."
  },
  {
    icon: <Star className="feature-icon" />,
    title: "Premium Quality",
    description: "Made with high-quality ingredients and materials for superior performance."
  },
  {
    icon: <BadgeCheck className="feature-icon" />,
    title: "Clinically Proven",
    description: "Our formulations are backed by clinical studies and real results."
  },
  {
    icon: <RefreshCcw className="feature-icon" />,
    title: "60-Day Guarantee",
    description: "Try risk-free with our 60-day money-back satisfaction guarantee."
  }
];

export default function FeaturesSection() {
  return (
    <section className="bg-gray-50 py-16">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="mb-2">Why Choose SmilePro Essentials</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We're committed to providing the highest quality dental care products 
            to help you maintain a healthy, beautiful smile.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="feature-card">
              {feature.icon}
              <h3 className="text-xl font-medium mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}