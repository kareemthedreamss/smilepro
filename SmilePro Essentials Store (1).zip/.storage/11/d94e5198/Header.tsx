import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, ShoppingBag, User, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";

const productCategories = [
  {
    title: "Teeth Whitening",
    description: "Professional-grade teeth whitening solutions.",
    href: "/shop/teeth-whitening",
  },
  {
    title: "Electric Toothbrushes",
    description: "Advanced cleaning with sonic technology.",
    href: "/shop/electric-toothbrushes",
  },
  {
    title: "Flossers & Tongue Scrapers",
    description: "Complete oral hygiene tools.",
    href: "/shop/flossers-scrapers",
  },
  {
    title: "Toothpaste & Mouthwash",
    description: "Sensitivity-safe formulations.",
    href: "/shop/toothpaste-mouthwash",
  },
];

export default function Header() {
  const [searchOpen, setSearchOpen] = useState(false);
  
  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b">
      <div className="container-custom py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-white font-bold text-lg">SP</span>
            </div>
            <span className="text-xl font-bold">
              Smile<span className="text-primary">Pro</span> Essentials
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Shop</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid gap-3 p-6 w-[400px] lg:w-[500px] lg:grid-cols-2">
                      {productCategories.map((category) => (
                        <li key={category.href} className="row-span-1">
                          <NavigationMenuLink asChild>
                            <Link
                              to={category.href}
                              className="block p-3 space-y-1 rounded-md hover:bg-accent"
                            >
                              <div className="text-sm font-medium leading-none">
                                {category.title}
                              </div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                {category.description}
                              </p>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                      <li className="lg:col-span-2">
                        <div className="w-full bg-accent/50 rounded-lg p-3 mt-2">
                          <Link
                            to="/shop"
                            className="text-primary hover:underline font-medium"
                          >
                            View All Products →
                          </Link>
                        </div>
                      </li>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/about" className="nav-link px-3 py-2">
                    About Us
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/blog" className="nav-link px-3 py-2">
                    Blog
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/contact" className="nav-link px-3 py-2">
                    Contact
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSearchOpen(!searchOpen)}
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </Button>
            <Link to="/account">
              <Button variant="ghost" size="icon" aria-label="Account">
                <User className="h-5 w-5" />
              </Button>
            </Link>
            <Link to="/cart">
              <Button variant="outline" className="flex gap-2" aria-label="Cart">
                <ShoppingBag className="h-4 w-4" />
                <span>Cart (0)</span>
              </Button>
            </Link>
          </div>

          {/* Mobile Navigation Trigger */}
          <div className="lg:hidden flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSearchOpen(!searchOpen)}
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </Button>
            <Link to="/cart">
              <Button variant="ghost" size="icon" aria-label="Cart">
                <ShoppingBag className="h-5 w-5" />
              </Button>
            </Link>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between">
                    <Link to="/" className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                        <span className="text-white font-bold text-sm">SP</span>
                      </div>
                      <span className="font-bold">SmilePro</span>
                    </Link>
                    <SheetClose asChild>
                      <Button variant="ghost" size="icon">
                        <X className="h-5 w-5" />
                      </Button>
                    </SheetClose>
                  </div>
                  <nav className="flex flex-col gap-4 mt-8">
                    <SheetClose asChild>
                      <Link to="/shop" className="py-2 text-lg font-medium">
                        Shop All
                      </Link>
                    </SheetClose>
                    {productCategories.map((category) => (
                      <SheetClose asChild key={category.href}>
                        <Link
                          to={category.href}
                          className="py-2 border-b border-border"
                        >
                          {category.title}
                        </Link>
                      </SheetClose>
                    ))}
                    <SheetClose asChild>
                      <Link to="/about" className="py-2 border-b border-border">
                        About Us
                      </Link>
                    </SheetClose>
                    <SheetClose asChild>
                      <Link to="/blog" className="py-2 border-b border-border">
                        Blog
                      </Link>
                    </SheetClose>
                    <SheetClose asChild>
                      <Link
                        to="/contact"
                        className="py-2 border-b border-border"
                      >
                        Contact
                      </Link>
                    </SheetClose>
                    <SheetClose asChild>
                      <Link
                        to="/account"
                        className="py-2 border-b border-border"
                      >
                        Account
                      </Link>
                    </SheetClose>
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="py-4 border-t">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for products..."
                className="pl-10"
              />
            </div>
          </div>
        )}
      </div>
    </header>
  );
}