import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Sample product data
const featuredProducts = [
  {
    id: 1,
    name: "Professional Teeth Whitening Kit",
    description: "Professional-grade whitening solution with LED light",
    price: 79.99,
    image: "https://images.unsplash.com/photo-1609840112990-4265448268d1?q=80&w=1000&auto=format&fit=crop",
    category: "Teeth Whitening",
    badge: "Best Seller",
    slug: "professional-teeth-whitening-kit"
  },
  {
    id: 2,
    name: "Sonic Electric Toothbrush",
    description: "40,000 vibrations per minute for superior cleaning",
    price: 129.99,
    salePrice: 99.99,
    image: "https://images.unsplash.com/photo-1559591937-a37bd9a4c732?q=80&w=1000&auto=format&fit=crop",
    category: "Electric Toothbrushes",
    badge: "Sale",
    slug: "sonic-electric-toothbrush"
  },
  {
    id: 3,
    name: "Premium Tongue Scraper (2-Pack)",
    description: "Stainless steel design for fresh breath",
    price: 14.99,
    image: "https://images.unsplash.com/photo-1612693655501-fd5437dbe4d0?q=80&w=1000&auto=format&fit=crop",
    category: "Flossers & Tongue Scrapers",
    slug: "premium-tongue-scraper-pack"
  },
  {
    id: 4,
    name: "Sensitivity Relief Toothpaste",
    description: "Clinically proven to reduce sensitivity",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1594320990326-399b05829bb6?q=80&w=1000&auto=format&fit=crop",
    category: "Toothpaste & Mouthwash",
    slug: "sensitivity-relief-toothpaste"
  }
];

export default function FeaturedProducts() {
  return (
    <section className="py-16">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8">
          <div>
            <h2 className="mb-2">Featured Products</h2>
            <p className="text-muted-foreground max-w-lg">
              Our most popular professional-grade dental products for a brighter, healthier smile.
            </p>
          </div>
          <Button variant="outline" asChild className="mt-4 md:mt-0">
            <Link to="/shop">View All Products</Link>
          </Button>
        </div>

        <div className="product-grid">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="product-card group overflow-hidden">
              <div className="aspect-square relative overflow-hidden bg-gray-100">
                {product.badge && (
                  <Badge className="product-badge" variant={product.badge === "Sale" ? "destructive" : "secondary"}>
                    {product.badge}
                  </Badge>
                )}
                <Link to={`/product/${product.slug}`}>
                  <img
                    src={product.image}
                    alt={product.name}
                    className="object-contain w-full h-full p-4 transition-transform group-hover:scale-105"
                  />
                </Link>
              </div>
              <CardContent className="pt-4">
                <div className="text-xs text-muted-foreground mb-1">
                  {product.category}
                </div>
                <Link to={`/product/${product.slug}`} className="block">
                  <h3 className="text-base font-medium mb-1 line-clamp-1">
                    {product.name}
                  </h3>
                </Link>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                  {product.description}
                </p>
                <div className="flex items-center gap-2">
                  {product.salePrice ? (
                    <>
                      <span className="sale-price">${product.salePrice}</span>
                      <span className="regular-price">${product.price}</span>
                    </>
                  ) : (
                    <span className="price">${product.price}</span>
                  )}
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <Button className="w-full" size="sm">
                  Add to Cart
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}