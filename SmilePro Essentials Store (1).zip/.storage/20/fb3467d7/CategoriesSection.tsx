import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

// Sample categories data
const categories = [
  {
    id: 1,
    name: "Teeth Whitening",
    description: "Professional-grade teeth whitening solutions for a brighter smile.",
    image: "https://images.unsplash.com/photo-1609840112990-4265448268d1?q=80&w=500&auto=format&fit=crop",
    href: "/shop/teeth-whitening",
  },
  {
    id: 2,
    name: "Electric Toothbrushes",
    description: "Advanced sonic technology for superior cleaning and gum health.",
    image: "https://images.unsplash.com/photo-1559591937-a37bd9a4c732?q=80&w=500&auto=format&fit=crop",
    href: "/shop/electric-toothbrushes",
  },
  {
    id: 3,
    name: "Flossers & Tongue Scrapers",
    description: "Complete your oral hygiene routine with essential tools.",
    image: "https://images.unsplash.com/photo-1612693655501-fd5437dbe4d0?q=80&w=500&auto=format&fit=crop",
    href: "/shop/flossers-scrapers",
  },
  {
    id: 4,
    name: "Toothpaste & Mouthwash",
    description: "Gentle yet effective formulations for daily use.",
    image: "https://images.unsplash.com/photo-1594320990326-399b05829bb6?q=80&w=500&auto=format&fit=crop",
    href: "/shop/toothpaste-mouthwash",
  },
];

export default function CategoriesSection() {
  return (
    <section className="py-16">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="mb-2">Shop By Category</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Browse our collection of professional dental care products organized by category.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link
              key={category.id}
              to={category.href}
              className="group overflow-hidden rounded-lg border border-border shadow-sm transition-all hover:shadow-md"
            >
              <div className="aspect-[4/3] relative overflow-hidden">
                <img
                  src={category.image}
                  alt={category.name}
                  className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-70"></div>
                <div className="absolute bottom-0 left-0 p-6 text-white">
                  <h3 className="text-xl font-medium mb-1">{category.name}</h3>
                  <p className="text-sm text-white/80 line-clamp-2">
                    {category.description}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="flex justify-center mt-10">
          <Button asChild variant="outline" size="lg">
            <Link to="/shop">View All Products</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}