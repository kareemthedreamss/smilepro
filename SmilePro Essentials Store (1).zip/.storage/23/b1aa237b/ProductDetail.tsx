import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Badge } from "@/components/ui/badge";
import {
  Star,
  ChevronRight,
  Minus,
  Plus,
  Check,
  Clock,
  Shield,
  Truck
} from "lucide-react";
import RelatedProducts from "@/components/product/RelatedProducts";
import ProductReviews from "@/components/product/ProductReviews";

// Product data (normally this would come from an API)
const products = {
  "professional-teeth-whitening-kit": {
    id: 1,
    name: "Professional Teeth Whitening Kit",
    slug: "professional-teeth-whitening-kit",
    price: 79.99,
    description: "Our professional-grade teeth whitening kit includes everything you need for a brighter smile. The dentist-approved formula is gentle on enamel while effectively removing years of stains.",
    longDescription: "Transform your smile from the comfort of your home with our Professional Teeth Whitening Kit. Designed by dental experts, this comprehensive kit delivers professional-level results without sensitivity or damage to your enamel. The advanced LED light technology accelerates the whitening process, while our proprietary enamel-safe formula removes years of coffee, wine, and tobacco stains.\n\nOur whitening gel is made in the USA using high-quality ingredients that are safe for daily use. Each kit includes enough treatment for 2-3 weeks of daily use, or up to 20 individual treatments.",
    sku: "SP-WK-001",
    category: "Teeth Whitening",
    inStock: true,
    isNew: true,
    isBestSeller: true,
    rating: 4.9,
    reviewCount: 124,
    images: [
      "https://images.unsplash.com/photo-1609840112990-4265448268d1?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1570357602089-7802ba1bd0e9?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1581389042957-7884cf0c4536?q=80&w=1000&auto=format&fit=crop"
    ],
    features: [
      "Professional-grade LED acceleration light",
      "16% Carbamide Peroxide whitening gel (4 syringes)",
      "Custom-fit mouth trays (2 included)",
      "Shade guide to track progress",
      "30-minute daily treatments",
      "Results in as little as 3 days",
      "Full results in 10-14 days",
      "Removes coffee, wine, and tobacco stains"
    ],
    includes: [
      "1 x LED Acceleration Light",
      "4 x Whitening Gel Syringes (3ml each)",
      "2 x Custom-Fit Mouth Trays",
      "1 x Shade Guide",
      "1 x Instruction Manual",
      "1 x Storage Case"
    ],
    howToUse: [
      "Brush your teeth before starting treatment",
      "Fill each tray with a thin line of gel",
      "Insert trays and turn on LED light",
      "Leave in for 30 minutes",
      "Remove, rinse trays and mouth thoroughly",
      "Use once daily for best results"
    ]
  }
};

export default function ProductDetail() {
  const { productSlug } = useParams<{ productSlug: string }>();
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState("description");
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  
  // If the product doesn't exist in our data, we could redirect to 404
  const product = products[productSlug as keyof typeof products];
  
  if (!product) {
    return (
      <Layout>
        <div className="container-custom py-12">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
            <p className="text-muted-foreground mb-6">
              The product you're looking for doesn't exist or has been removed.
            </p>
            <Button asChild>
              <Link to="/shop">Continue Shopping</Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  const handleQuantityChange = (change: number) => {
    const newQuantity = quantity + change;
    if (newQuantity > 0 && newQuantity <= 10) {
      setQuantity(newQuantity);
    }
  };

  const handleAddToCart = () => {
    // Here we would normally add the product to cart
    // For now we'll just console.log
    console.log(`Added ${quantity} of ${product.name} to cart`);
  };
  
  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-gray-50 py-3">
        <div className="container-custom">
          <div className="flex items-center text-sm text-muted-foreground">
            <Link to="/" className="hover:text-primary">Home</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <Link to="/shop" className="hover:text-primary">Shop</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <Link to={`/shop/${product.category.toLowerCase().replace(' ', '-')}`} className="hover:text-primary">
              {product.category}
            </Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-foreground font-medium truncate max-w-[200px]">
              {product.name}
            </span>
          </div>
        </div>
      </div>

      {/* Product Detail */}
      <section className="py-12">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="rounded-lg overflow-hidden border border-border bg-white">
                <img
                  src={product.images[selectedImageIndex]}
                  alt={product.name}
                  className="w-full h-auto aspect-square object-contain p-4"
                />
              </div>
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImageIndex(index)}
                    className={`rounded-md overflow-hidden border ${
                      selectedImageIndex === index
                        ? "border-primary ring-2 ring-primary/20"
                        : "border-border"
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-auto aspect-square object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              {/* Product title and badges */}
              <div>
                {product.isNew && (
                  <Badge className="mb-2">New Arrival</Badge>
                )}
                {product.isBestSeller && (
                  <Badge variant="secondary" className="mb-2 ml-2">Best Seller</Badge>
                )}
                <h1 className="text-3xl font-bold">{product.name}</h1>

                {/* Rating */}
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex">
                    {Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating)
                              ? "text-yellow-400 fill-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                  </div>
                  <span className="text-sm font-medium">{product.rating}</span>
                  <Link to="#reviews" className="text-sm text-muted-foreground hover:text-primary">
                    ({product.reviewCount} reviews)
                  </Link>
                </div>
              </div>

              {/* Price */}
              <div>
                <span className="text-3xl font-bold">${product.price.toFixed(2)}</span>
                <p className="text-sm text-muted-foreground mt-1">
                  Free shipping on orders over $50
                </p>
              </div>

              {/* Short Description */}
              <p className="text-muted-foreground">
                {product.description}
              </p>

              {/* Availability */}
              <div className="flex items-center gap-2 text-sm">
                <span className="text-muted-foreground">Availability:</span>
                {product.inStock ? (
                  <span className="flex items-center text-green-600 font-medium">
                    <Check className="h-4 w-4 mr-1" /> In Stock
                  </span>
                ) : (
                  <span className="flex items-center text-red-500 font-medium">
                    <Clock className="h-4 w-4 mr-1" /> Out of Stock
                  </span>
                )}
              </div>

              {/* SKU */}
              <div className="text-sm text-muted-foreground">
                SKU: <span className="font-medium text-foreground">{product.sku}</span>
              </div>

              <Separator />

              {/* Add to Cart */}
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-border rounded-md">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleQuantityChange(-1)}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-12 text-center">{quantity}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleQuantityChange(1)}
                      disabled={quantity >= 10}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button
                    size="lg"
                    className="flex-1"
                    onClick={handleAddToCart}
                  >
                    Add to Cart
                  </Button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6">
                  <div className="flex flex-col items-center text-center p-3 border border-border rounded-md bg-accent/30">
                    <Shield className="h-6 w-6 text-primary mb-2" />
                    <span className="text-xs font-medium">60-Day Money-Back Guarantee</span>
                  </div>
                  <div className="flex flex-col items-center text-center p-3 border border-border rounded-md bg-accent/30">
                    <Truck className="h-6 w-6 text-primary mb-2" />
                    <span className="text-xs font-medium">Free Shipping Over $50</span>
                  </div>
                  <div className="flex flex-col items-center text-center p-3 border border-border rounded-md bg-accent/30">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary mb-2"
                    >
                      <path d="m8 14-6 6h9v-3" />
                      <path d="M18.37 3.63 8 14l3 3L21.37 6.63a2.12 2.12 0 1 0-3-3Z" />
                    </svg>
                    <span className="text-xs font-medium">Dentist Approved</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Product Tabs */}
          <div className="mt-16">
            <Tabs 
              defaultValue="description" 
              className="w-full"
              value={activeTab}
              onValueChange={setActiveTab}
            >
              <TabsList className="grid grid-cols-3 w-full max-w-lg mx-auto">
                <TabsTrigger value="description">Description</TabsTrigger>
                <TabsTrigger value="details">Details & How to Use</TabsTrigger>
                <TabsTrigger value="reviews" id="reviews">Reviews ({product.reviewCount})</TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="mt-8">
                <div className="max-w-3xl mx-auto">
                  <h3 className="text-xl font-medium mb-4">Product Description</h3>
                  <div className="prose prose-sm sm:prose">
                    {product.longDescription.split('\n\n').map((paragraph, index) => (
                      <p key={index} className="mb-4 text-muted-foreground">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                  
                  <h3 className="text-xl font-medium mt-8 mb-4">Key Features</h3>
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-muted-foreground">
                        <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>
              <TabsContent value="details" className="mt-8">
                <div className="max-w-3xl mx-auto grid gap-8 md:grid-cols-2">
                  <div>
                    <h3 className="text-xl font-medium mb-4">What's Included</h3>
                    <ul className="space-y-2">
                      {product.includes.map((item, index) => (
                        <li key={index} className="flex items-start gap-2 text-muted-foreground">
                          <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-medium mb-4">How to Use</h3>
                    <ol className="space-y-4">
                      {product.howToUse.map((step, index) => (
                        <li key={index} className="flex items-start gap-3 text-muted-foreground">
                          <div className="h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 mt-0.5 font-medium text-sm">
                            {index + 1}
                          </div>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="reviews" className="mt-8">
                <ProductReviews productId={product.id} rating={product.rating} reviewCount={product.reviewCount} />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>
      
      {/* Related Products Section */}
      <section className="py-12 bg-gray-50">
        <div className="container-custom">
          <h2 className="text-2xl font-bold mb-8">You Might Also Like</h2>
          <RelatedProducts currentProductId={product.id} />
        </div>
      </section>
    </Layout>
  );
}