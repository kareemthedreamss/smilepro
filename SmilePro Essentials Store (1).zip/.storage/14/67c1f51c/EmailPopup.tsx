import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function EmailPopup() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    // Show popup after 5 seconds
    const timer = setTimeout(() => {
      const hasSeenPopup = localStorage.getItem("smilePro-popup-seen");
      if (!hasSeenPopup) {
        setOpen(true);
      }
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  const handleSubscribe = () => {
    localStorage.setItem("smilePro-popup-seen", "true");
    setOpen(false);
    // Here you would normally handle the email submission
  };

  const handleClose = () => {
    localStorage.setItem("smilePro-popup-seen", "true");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <Button 
          className="absolute right-4 top-4" 
          variant="ghost" 
          size="icon"
          onClick={handleClose}
        >
          <X className="h-4 w-4" />
        </Button>
        <DialogHeader>
          <DialogTitle className="text-center text-2xl">Get 10% Off Today!</DialogTitle>
        </DialogHeader>
        <div className="p-6 flex flex-col items-center">
          <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="24" 
              height="24" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="text-primary h-8 w-8"
            >
              <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
              <path d="m9 12 2 2 4-4"></path>
            </svg>
          </div>
          <p className="text-center text-muted-foreground mb-6">
            Sign up for our newsletter to receive exclusive offers, oral care tips, and 10% off your first order!
          </p>
          <div className="w-full space-y-4">
            <Input 
              type="email" 
              placeholder="Your email address" 
              className="w-full" 
            />
            <Button 
              className="w-full" 
              onClick={handleSubscribe}
            >
              Get My 10% Off
            </Button>
          </div>
          <p className="text-xs text-center mt-4 text-muted-foreground">
            By subscribing, you agree to receive marketing emails from SmilePro Essentials.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}