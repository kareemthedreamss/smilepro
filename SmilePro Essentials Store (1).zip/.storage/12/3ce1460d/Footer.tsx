import { Link } from "react-router-dom";
import { Facebook, Instagram, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

export default function Footer() {
  return (
    <footer className="bg-gray-50">
      {/* Email Signup */}
      <div className="container-custom py-12">
        <div className="email-signup">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-2xl font-bold mb-2">Get 10% Off Your First Order</h2>
            <p className="text-muted-foreground mb-6">
              Sign up for our newsletter to receive special offers, oral care tips, and exclusive deals.
            </p>
            <div className="flex gap-2 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Your email address"
                className="bg-white"
              />
              <Button>Subscribe</Button>
            </div>
          </div>
        </div>
      </div>
      
      <Separator />
      
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Logo and About */}
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-white font-bold text-lg">SP</span>
              </div>
              <span className="text-xl font-bold">
                Smile<span className="text-primary">Pro</span> Essentials
              </span>
            </Link>
            <p className="text-muted-foreground mb-4">
              Professional dental care products designed to give you confidence through
              superior oral care. Dentist-approved, gentle on enamel, and effective.
            </p>
            <div className="flex gap-4">
              <a href="https://facebook.com" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="https://instagram.com" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://twitter.com" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          {/* Navigation Links */}
          <div>
            <h3 className="footer-heading mb-4">Shop</h3>
            <nav className="flex flex-col space-y-3">
              <Link to="/shop/teeth-whitening" className="footer-link">Teeth Whitening</Link>
              <Link to="/shop/electric-toothbrushes" className="footer-link">Electric Toothbrushes</Link>
              <Link to="/shop/flossers-scrapers" className="footer-link">Flossers & Tongue Scrapers</Link>
              <Link to="/shop/toothpaste-mouthwash" className="footer-link">Toothpaste & Mouthwash</Link>
              <Link to="/shop" className="footer-link">All Products</Link>
            </nav>
          </div>
          
          <div>
            <h3 className="footer-heading mb-4">Information</h3>
            <nav className="flex flex-col space-y-3">
              <Link to="/about" className="footer-link">About Us</Link>
              <Link to="/blog" className="footer-link">Blog</Link>
              <Link to="/contact" className="footer-link">Contact Us</Link>
              <Link to="/faq" className="footer-link">FAQ</Link>
              <Link to="/shipping-returns" className="footer-link">Shipping & Returns</Link>
            </nav>
          </div>
          
          <div>
            <h3 className="footer-heading mb-4">My Account</h3>
            <nav className="flex flex-col space-y-3">
              <Link to="/account" className="footer-link">My Account</Link>
              <Link to="/account/orders" className="footer-link">Order History</Link>
              <Link to="/cart" className="footer-link">Shopping Cart</Link>
              <Link to="/track-order" className="footer-link">Track My Order</Link>
            </nav>
          </div>
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="border-t border-border">
        <div className="container-custom py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-muted-foreground text-sm">
              © {new Date().getFullYear()} SmilePro Essentials. All rights reserved.
            </p>
            <div className="flex gap-4 text-sm">
              <Link to="/privacy-policy" className="text-muted-foreground hover:text-primary">
                Privacy Policy
              </Link>
              <Link to="/terms-conditions" className="text-muted-foreground hover:text-primary">
                Terms & Conditions
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}