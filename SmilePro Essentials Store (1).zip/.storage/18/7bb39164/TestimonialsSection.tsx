import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Card } from "@/components/ui/card";
import { Star } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Verified Customer",
    content: "I've tried many whitening products before, but SmilePro's kit is the only one that gave me noticeable results without sensitivity. My teeth are 5 shades whiter after just two weeks!",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/women/42.jpg"
  },
  {
    id: 2,
    name: "Michael Thompson",
    role: "Verified Customer",
    content: "The sonic toothbrush is worth every penny. My teeth feel professionally cleaned after every use, and the battery lasts for weeks. Highly recommend!",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/men/32.jpg"
  },
  {
    id: 3,
    name: "Jennifer Lee",
    role: "Verified Customer",
    content: "As someone with sensitive teeth, I was skeptical about whitening products. SmilePro's sensitivity-free formula is a game changer! No pain, all gain.",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/women/24.jpg"
  },
  {
    id: 4,
    name: "David Wilson",
    role: "Verified Customer",
    content: "The customer service is as excellent as their products. Had an issue with shipping and they resolved it immediately and even sent a free gift!",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/men/45.jpg"
  },
  {
    id: 5,
    name: "Emma Roberts",
    role: "Verified Customer",
    content: "After using the complete SmilePro routine for a month, I've received so many compliments on my smile. These products are now a permanent part of my oral care.",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/women/19.jpg"
  }
];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex">
      {Array(5)
        .fill(0)
        .map((_, i) => (
          <Star
            key={i}
            className={`h-4 w-4 ${
              i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
            }`}
          />
        ))}
    </div>
  );
}

export default function TestimonialsSection() {
  return (
    <section className="py-16">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="mb-2">What Our Customers Say</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it. Here's what our satisfied customers have to say about their experience with SmilePro Essentials.
          </p>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent>
            {testimonials.map((testimonial) => (
              <CarouselItem key={testimonial.id} className="md:basis-1/2 lg:basis-1/3 pl-4">
                <div className="p-1">
                  <Card className="testimonial-card h-full">
                    <div className="flex flex-col h-full">
                      <div className="mb-4">
                        <StarRating rating={testimonial.rating} />
                      </div>
                      <p className="flex-grow text-muted-foreground mb-6 italic">
                        "{testimonial.content}"
                      </p>
                      <div className="flex items-center gap-3">
                        <img
                          src={testimonial.avatar}
                          alt={testimonial.name}
                          className="h-10 w-10 rounded-full object-cover"
                        />
                        <div>
                          <h4 className="text-sm font-medium">{testimonial.name}</h4>
                          <p className="text-xs text-muted-foreground">
                            {testimonial.role}
                          </p>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="flex justify-center mt-8 gap-2">
            <CarouselPrevious className="static translate-y-0" />
            <CarouselNext className="static translate-y-0" />
          </div>
        </Carousel>
      </div>
    </section>
  );
}