import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, ThumbsUp } from "lucide-react";
import { Separator } from "@/components/ui/separator";

// Sample review data
const reviews = [
  {
    id: 1,
    author: "Melissa R.",
    avatar: "https://randomuser.me/api/portraits/women/22.jpg",
    initials: "MR",
    date: "March 15, 2025",
    rating: 5,
    title: "Best whitening product I've ever used!",
    content: "I've tried so many whitening products over the years, but this is the first one that actually delivered noticeable results without causing any sensitivity. After just one week, my teeth were visibly whiter. The custom-fit trays are comfortable and the LED light is easy to use. Highly recommend!",
    helpful: 18,
    verified: true,
  },
  {
    id: 2,
    author: "David K.",
    avatar: "https://randomuser.me/api/portraits/men/36.jpg",
    initials: "DK",
    date: "February 28, 2025",
    rating: 4,
    title: "Great results, slight learning curve",
    content: "This whitening kit really works! It took me a couple of tries to get the hang of using the mouth trays properly, but once I did, the results were impressive. My coffee stains are gone and my teeth look years younger. The only reason I'm giving 4 stars instead of 5 is that the gel can be a little messy at first.",
    helpful: 7,
    verified: true,
  },
  {
    id: 3,
    author: "Samantha T.",
    avatar: "https://randomuser.me/api/portraits/women/65.jpg",
    initials: "ST",
    date: "March 10, 2025",
    rating: 5,
    title: "Worth every penny!",
    content: "After using this kit for two weeks, I received so many compliments on my smile! The before and after difference is incredible. I appreciate that the product comes with multiple gel syringes so you can do touch-ups as needed. The LED light makes the process quick and efficient. Will definitely purchase again when I need a refresh.",
    helpful: 12,
    verified: true,
  }
];

// Calculate rating distribution
const calculateRatingDistribution = (reviewCount: number) => {
  // In a real app, this would come from the backend
  // For this demo, we'll create some reasonable distribution
  return {
    5: Math.round(reviewCount * 0.7), // 70% are 5-star
    4: Math.round(reviewCount * 0.2), // 20% are 4-star
    3: Math.round(reviewCount * 0.05), // 5% are 3-star
    2: Math.round(reviewCount * 0.03), // 3% are 2-star
    1: Math.round(reviewCount * 0.02), // 2% are 1-star
  };
};

interface ProductReviewsProps {
  productId: number;
  rating: number;
  reviewCount: number;
}

export default function ProductReviews({ productId, rating, reviewCount }: ProductReviewsProps) {
  const [filter, setFilter] = useState("most-recent");
  const [expandedReviewId, setExpandedReviewId] = useState<number | null>(null);
  const [helpfulReviews, setHelpfulReviews] = useState<number[]>([]);

  const ratingDistribution = calculateRatingDistribution(reviewCount);
  
  // Demo reviews are limited to 3, but we'll set up the component as if there could be more
  const visibleReviews = reviews.slice(0, 3);
  
  const toggleExpandReview = (reviewId: number) => {
    if (expandedReviewId === reviewId) {
      setExpandedReviewId(null);
    } else {
      setExpandedReviewId(reviewId);
    }
  };
  
  const markHelpful = (reviewId: number) => {
    if (!helpfulReviews.includes(reviewId)) {
      setHelpfulReviews([...helpfulReviews, reviewId]);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="grid md:grid-cols-5 gap-12">
        {/* Rating Summary */}
        <div className="md:col-span-2 space-y-6">
          <div className="text-center md:text-left">
            <div className="text-5xl font-bold">{rating}</div>
            <div className="flex justify-center md:justify-start mt-2">
              {Array(5)
                .fill(0)
                .map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(rating)
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                ))}
            </div>
            <div className="text-sm text-muted-foreground mt-2">
              Based on {reviewCount} reviews
            </div>
          </div>
          
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((star) => (
              <div key={star} className="flex items-center gap-2">
                <div className="w-10 text-right text-sm">{star} star</div>
                <div className="flex-1">
                  <Progress 
                    value={(ratingDistribution[star as keyof typeof ratingDistribution] / reviewCount) * 100} 
                    className="h-2" 
                  />
                </div>
                <div className="w-10 text-left text-sm text-muted-foreground">
                  {ratingDistribution[star as keyof typeof ratingDistribution]}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Reviews List */}
        <div className="md:col-span-3 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">Customer Reviews</h3>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="most-recent">Most Recent</SelectItem>
                <SelectItem value="highest-rating">Highest Rating</SelectItem>
                <SelectItem value="lowest-rating">Lowest Rating</SelectItem>
                <SelectItem value="most-helpful">Most Helpful</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {visibleReviews.map((review) => (
            <div key={review.id} className="space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={review.avatar} alt={review.author} />
                    <AvatarFallback>{review.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center">
                      <span className="font-medium">{review.author}</span>
                      {review.verified && (
                        <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded">
                          Verified Purchase
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {review.date}
                    </div>
                  </div>
                </div>
                <div className="flex">
                  {Array(5)
                    .fill(0)
                    .map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < review.rating
                            ? "text-yellow-400 fill-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-1">{review.title}</h4>
                <p className={`text-muted-foreground text-sm ${
                  expandedReviewId === review.id ? '' : 'line-clamp-3'
                }`}>
                  {review.content}
                </p>
                {review.content.length > 150 && (
                  <button
                    onClick={() => toggleExpandReview(review.id)}
                    className="text-xs text-primary font-medium mt-1"
                  >
                    {expandedReviewId === review.id ? "Show less" : "Read more"}
                  </button>
                )}
              </div>
              
              <div className="flex items-center">
                <Button
                  variant="ghost"
                  size="sm"
                  className={`text-xs flex items-center gap-1 ${
                    helpfulReviews.includes(review.id) ? "text-primary" : "text-muted-foreground"
                  }`}
                  onClick={() => markHelpful(review.id)}
                  disabled={helpfulReviews.includes(review.id)}
                >
                  <ThumbsUp className="h-3 w-3" />
                  Helpful ({helpfulReviews.includes(review.id) ? review.helpful + 1 : review.helpful})
                </Button>
              </div>
              
              <Separator />
            </div>
          ))}
          
          {/* We'd show a load more button here if there were more reviews */}
          {reviewCount > visibleReviews.length && (
            <div className="flex justify-center mt-8">
              <Button variant="outline">
                Load More Reviews
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}